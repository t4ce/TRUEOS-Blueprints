//! Finite, externally launched acceptance for the forked native serial compiler.
//! The compiler archive is deliberately renamed so its source DB is isolated.

use std::fs;
use std::io::{self, Write};
use trueos::{child_hull, clock, logl, vsys};

#[cfg(feature = "compiler-child-stdio")]
const COMPILER: &str = "/rustcnat1027.bp";
const CHILD_TIMEOUT_NS: u64 = 240_000_000_000;
const MAX_OUTPUT_BYTES: usize = 2 * 1024 * 1024;
#[cfg(any(test, feature = "compiler-child-stdio"))]
const PHASES: &[&str] = &[
    "submitted", "admitted", "entered", "configured", "parsed", "expanded", "analyzed",
    "emitted", "published", "completed",
];
#[cfg(feature = "compiler-child-stdio")]
const FIXTURE_SOURCE: &str = include_str!("fixture.rs");

fn report(message: impl std::fmt::Display) {
    println!("rustc-native-probe: {message}");
    let _ = logl::log_record(logl::level::IMPORTANT, "rustc-native-probe", format_args!("{message}"));
}

fn run_child(label: &str, program: &str, args: &[&str]) -> Result<String, String> {
    let request = serde_json::to_vec(&serde_json::json!({
        "program": program,
        "args": args,
        "env": {"SERIAL_PROBE": "ok"},
        "cwd": null
    })).map_err(|error| error.to_string())?;
    let handle = child_hull::spawn_program(&request)
        .map_err(|code| format!("{label}: spawn {program} failed ({code})"))?;
    let started = clock::monotonic_nanos();
    report(format_args!("child-start label={label} handle={handle} program={program}"));
    let mut output = Vec::new();
    let mut buffer = [0u8; 4096];
    loop {
        loop {
            let n = child_hull::read(handle, &mut buffer)
                .map_err(|code| format!("{label}: child read failed ({code})"))?;
            if n == 0 { break; }
            if n > MAX_OUTPUT_BYTES.saturating_sub(output.len()) {
                let _ = child_hull::terminate(handle);
                return Err(format!("{label}: output exceeded {MAX_OUTPUT_BYTES} bytes"));
            }
            output.extend_from_slice(&buffer[..n]);
            let _ = io::stdout().write_all(&buffer[..n]);
            let _ = logl::log_record(logl::level::IMPORTANT, "rustc-native-child", format_args!(
                "label={label} {}", String::from_utf8_lossy(&buffer[..n])
            ));
        }
        let state = child_hull::status(handle);
        if state == child_hull::STATUS_EXITED {
            // EXITED can be observed just after the previous empty read.
            loop {
                let n = child_hull::read(handle, &mut buffer)
                    .map_err(|code| format!("{label}: final read failed ({code})"))?;
                if n == 0 { break; }
                if n > MAX_OUTPUT_BYTES.saturating_sub(output.len()) {
                    return Err(format!("{label}: final output exceeded limit"));
                }
                output.extend_from_slice(&buffer[..n]);
                let _ = io::stdout().write_all(&buffer[..n]);
            }
            report(format_args!("child-exit label={label} elapsed_ns={} output_bytes={}",
                clock::monotonic_nanos().saturating_sub(started), output.len()));
            return Ok(String::from_utf8_lossy(&output).into_owned());
        }
        if state < 0 { return Err(format!("{label}: child status failed ({state})")); }
        if clock::monotonic_nanos().saturating_sub(started) > CHILD_TIMEOUT_NS {
            let _ = child_hull::terminate(handle);
            return Err(format!("{label}: finite child timeout after 240 seconds"));
        }
        // This VMCALL yields the Hull; it does not busy-poll a host executor.
        vsys::sleep_ms(10);
    }
}

#[cfg(any(test, feature = "compiler-child-stdio"))]
fn check_phases(output: &str) -> Result<(), String> {
    let mut offset = 0;
    for phase in PHASES {
        let marker = format!("phase={phase} ");
        let found = output[offset..].find(&marker)
            .ok_or_else(|| format!("missing or unordered compiler phase {phase}"))?;
        offset += found + marker.len();
    }
    if output.contains("phase=failed ") || output.contains("phase=rejected ") {
        return Err(String::from("compiler reported a failed execution phase"));
    }
    Ok(())
}

#[cfg(feature = "compiler-child-stdio")]
fn contains(output: &str, expected: &str) -> Result<(), String> {
    if output.contains(expected) { Ok(()) }
    else { Err(format!("expected child output missing: {expected}")) }
}

#[cfg(feature = "compiler-child-stdio")]
fn run_compiler_suite() -> Result<(), String> {
    // A fresh archive basename isolates the compiler's existing app-private DB.
    let run_id = clock::monotonic_nanos();
    let project = format!("native-serial-{run_id:x}");
    let root = format!("apps/common/rustc-native-probe-{run_id:x}");
    fs::create_dir_all(&root).map_err(|error| format!("create unique probe root: {error}"))?;
    report(format_args!("begin compiler={COMPILER} project={project} artifacts=/{root}"));

    let source = format!("{root}/source");
    fs::create_dir_all(&source).map_err(|error| error.to_string())?;
    fs::write(format!("{source}/main.rs"), FIXTURE_SOURCE).map_err(|error| error.to_string())?;
    let archive = format!("{root}/fixture.7z");
    let packed = trueos::async_fs::block_on(trueos::archive::pack(source.as_bytes(), archive.as_bytes()))
        .map_err(|code| format!("kernel source archive pack failed ({code})"))?;
    if packed.file_count != 1 { return Err(format!("archive has {} files, expected one", packed.file_count)); }
    report(format_args!("archive-created files={} source_bytes={} archive_bytes={}",
        packed.file_count, packed.input_bytes, packed.output_bytes));
    // Compiler retains its normal confined app/common FS scope.
    let common = root.strip_prefix("apps/").unwrap();
    let archive_arg = format!("/{common}/fixture.7z");
    let output_arg = format!("/{common}/fixture.bp");
    let imported = run_child("source-import", COMPILER,
        &["source", "import-7z", &project, &archive_arg])?;
    fs::write(format!("{root}/source-import.txt"), &imported).map_err(|error| error.to_string())?;
    contains(&imported, "revision=1")?;
    let verified = run_child("source-verify", COMPILER, &["source", "verify"])?;
    contains(&verified, "database verified")?;
    let compiled = run_child("database-compile", COMPILER,
        &["source", "compile", &project, "latest", "--output", &output_arg])?;
    fs::write(format!("{root}/database-compile.txt"), &compiled).map_err(|error| error.to_string())?;
    check_phases(&compiled)?;
    contains(&compiled, "database Blueprint compile passed")?;
    let fixture = fs::read(format!("{root}/fixture.bp")).map_err(|error| error.to_string())?;
    if !fixture.starts_with(b"TRBP") { return Err("database output lacks TRBP header".into()); }
    let executed = run_child("database-output", &format!("/{root}/fixture.bp"), &["native-serial-fixture"])?;
    fs::write(format!("{root}/database-output.txt"), &executed).map_err(|error| error.to_string())?;
    contains(&executed, "rustc-native-fixture: PASS argv=1 env=1")?;
    report(format_args!("PASS database=redb revision=1 compile_phases=ordered generated_blueprint=executed argv=observed env=observed artifacts=/{root}"));
    Ok(())
}

fn run() -> Result<(), String> {
    let path = "/apps/common/localcompile/local.bp";
    let bytes = fs::read(path).map_err(|error| format!("read existing compiler output {path}: {error}"))?;
    if !bytes.starts_with(b"TRBP") { return Err("compiler output lacks TRBP header".into()); }
    report(format_args!("generated-output-start path={path} bytes={}", bytes.len()));
    let output = run_child("default-output", path, &[])?;
    report(format_args!("generated-output-exited stdio_bytes={} kernel-console-expected=hello_world: rustc native-serial", output.len()));
    // The artifact writes trueos_cabi_write directly. The kernel records its
    // hello marker; completion alone is not presented as observation of text.
    #[cfg(feature = "compiler-child-stdio")]
    run_compiler_suite()?;
    #[cfg(not(feature = "compiler-child-stdio"))]
    report("database-suite SKIP native compiler carrier stdout is unsupported by current child-process bridge; no compiler child was launched");
    Ok(())
}

fn main() {
    if let Err(error) = run() { report(format_args!("FAIL {error}")); }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn marker_validator_requires_real_order_and_rejects_failed_tail() {
        let output = PHASES.iter().map(|phase| format!("id=1 phase={phase} elapsed_ns=1\n")).collect::<String>();
        assert!(check_phases(&output).is_ok());
        assert!(check_phases(&output.replace("phase=parsed ", "phase=missing ")).is_err());
        assert!(check_phases(&(output + "id=1 phase=failed elapsed_ns=2")).is_err());
    }
}
