#![no_std]
#![no_main]

unsafe extern "C" {
    fn trueos_cabi_env_args_count() -> usize;
    fn trueos_cabi_env_arg(index: usize, out: *mut u8, cap: usize) -> isize;
    fn trueos_cabi_env_var(key: *const u8, key_len: usize, out: *mut u8, cap: usize) -> isize;
    fn trueos_cabi_blueprint_child_send_v1(handle: u64, data: *const u8, len: usize) -> isize;
    fn trueos_cabi_write(stream: u32, data: *const u8, len: usize);
}

#[unsafe(no_mangle)]
pub extern "C" fn _start() {
    let mut arg = [0u8; 64];
    let mut env = [0u8; 64];
    let key = b"SERIAL_PROBE";
    let arg_len = unsafe { trueos_cabi_env_arg(1, arg.as_mut_ptr(), arg.len()) };
    let env_len = unsafe { trueos_cabi_env_var(key.as_ptr(), key.len(), env.as_mut_ptr(), env.len()) };
    let pass = unsafe { trueos_cabi_env_args_count() } == 2
        && arg_len == 21 && &arg[..21] == b"native-serial-fixture"
        && env_len == 2 && &env[..2] == b"ok";
    let message: &[u8] = if pass {
        b"rustc-native-fixture: PASS argv=1 env=1\n"
    } else {
        b"rustc-native-fixture: FAIL argv-or-env\n"
    };
    unsafe {
        trueos_cabi_blueprint_child_send_v1(0, message.as_ptr(), message.len());
        trueos_cabi_write(1, message.as_ptr(), message.len());
    }
}
